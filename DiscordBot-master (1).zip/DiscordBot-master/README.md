# FiveM-Status-Discord-Bot by Zofux
 

# Do not put this in your server resources, this is ment to run outside of your server and will not work if you try to run it of your server

FiveM server status bot, this will display how many users are online in your server thru the status of a discord bot.
Please try to find out why your code is not working your self before trying to contact me because this a really simply project and should not be hard to understand.

Stuff you should have installed and other usefull links | To run the code use the command "node ." in the command line.

Node.js is used to let javascript run on it's own | https://nodejs.org/en/

Visual Studio code is used to edit our code | https://code.visualstudio.com/download

Discord Developer Portal | https://discord.com/developers/applications

If you want a step by step tutorial here is a video a made https://www.youtube.com/watch?v=9TCCDHT1cTY
